package com.example.buzzrfrontend.data;

import android.content.Context;
import android.content.Intent;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.RequestFuture;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.buzzrfrontend.data.model.LoggedInUser;
import com.example.buzzrfrontend.data.model.UserData;
import com.example.buzzrfrontend.data.model.UserType;
import com.example.buzzrfrontend.ui.loginView.LoginActivity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */

public class LoginDataSource {
    private RequestQueue requestQueue;
    private List<LoggedInUser> loggedInUser = new ArrayList<>();

    public Result<LoggedInUser> login(String username, String password, Context context) {

        try {
            // TODO: handle loggedInUser authentication
            LoggedInUser fakeUser =
                    new LoggedInUser(0,
                            "Buzzr Name",
                            "Buzzr User",
                            "Buzzr Email",
                            "5555555555",
                            "Password",
                            UserType.client);
            return new Result.Success<>(fakeUser);
        } catch (Exception e) {
            //Toast.makeText(Context., "", 0).show();
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public void logout(Context context, LoggedInUser user) {
        user.logout();
        Intent intent = new Intent(context, LoginActivity.class);
        context.startActivity(intent);
    }

    private void setLoggedInUser(LoggedInUser usr) {
        loggedInUser.add(usr);
    }

    // attempt to fix login
    private void validateUser(String username, String password, Context context) {
        final String user = username;
        final String pass = password;

        requestQueue = Volley.newRequestQueue(context);
        JsonArrayRequest req = new JsonArrayRequest(Const.URL + Const.listPersonsEndpoint,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i = 0; i < response.length(); i++)
                        {
                            try {
                                JSONObject JsonObj = response.getJSONObject(i);
                                if(JsonObj.getString("username").equals(user) && JsonObj.getString("password").equals(pass)){
                                    UserData usrData = new UserData();
                                    usrData.setUserName(JsonObj.getString("username"));
                                    usrData.setEmail(JsonObj.getString("email"));
                                    usrData.setId(JsonObj.getInt("id"));
                                    usrData.setPassword(JsonObj.getString("password"));
                                    usrData.setPhoneNumber(JsonObj.getString("phoneNo"));
                                    switch(JsonObj.getString("userType").toLowerCase()) {
                                        case "admin": usrData.setUserType(UserType.admin); break;
                                        case "client": usrData.setUserType(UserType.client); break;
                                        case "barber": usrData.setUserType(UserType.barber); break;
                                        default: usrData.setUserType(UserType.client); break;
                                    }
                                    LoggedInUser lusr = new LoggedInUser(usrData);
                                    setLoggedInUser(lusr);
                                    return;
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("Volley", "Error: " + error.getMessage());
            }
        });
        requestQueue.add(req);
    }

}