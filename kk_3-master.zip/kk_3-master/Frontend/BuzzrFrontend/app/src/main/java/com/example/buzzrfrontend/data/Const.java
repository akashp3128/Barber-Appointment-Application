package com.example.buzzrfrontend.data;

public class Const {
    public static final String URL = "http://coms-309-kk-03.cs.iastate.edu:8080";
    public static final String listPersonsEndpoint = "/persons";
}