package com.example.buzzrfrontend.DRVinterface;

public interface LoadMore
{
    void onLoadMore();
}
