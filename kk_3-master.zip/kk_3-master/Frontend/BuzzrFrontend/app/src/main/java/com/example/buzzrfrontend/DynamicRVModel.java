package com.example.buzzrfrontend;

public class DynamicRVModel
{
    String name;
    int id;

    public DynamicRVModel(String name, int id)
    {
        this.name = name;
        this.id = id;
    }

    public String getName()
    {
        return name;
    }
    public int getId()
    {
        return id;
    }
}
