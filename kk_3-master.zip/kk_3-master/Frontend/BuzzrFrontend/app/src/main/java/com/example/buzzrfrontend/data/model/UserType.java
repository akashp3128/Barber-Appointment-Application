package com.example.buzzrfrontend.data.model;

public enum UserType {
    admin,
    client,
    barber
}
