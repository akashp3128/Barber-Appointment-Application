package com.example.buzzrfrontend.data;

import android.app.Application;

import com.example.buzzrfrontend.data.model.LoggedInUser;

public class ApplicationVar extends Application {
    @Override
    public void onCreate()
    {
        super.onCreate();
    }

    private LoggedInUser loggedInUser;
    private Navigation nav;

    public LoggedInUser getLoggedInUser()
    {
        return loggedInUser;
    }
    public void setLoggedInUser(LoggedInUser loggedInUser) {
        this.loggedInUser = loggedInUser;
    }

    public Navigation getNav() {
        return nav;
    }
    public void setNav(Navigation nav)
    {
        this.nav = nav;
    }

}
