package com.example.buzzrfrontend.ui.loginView;

import android.app.Activity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.buzzrfrontend.data.ApplicationVar;
import com.example.buzzrfrontend.R;
import com.example.buzzrfrontend.data.Const;
import com.example.buzzrfrontend.data.Navigation;
import com.example.buzzrfrontend.data.model.LoggedInUser;
import com.example.buzzrfrontend.data.model.UserData;
import com.example.buzzrfrontend.data.model.UserType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.example.buzzrfrontend.data.model.UserType.admin;
import static com.example.buzzrfrontend.data.model.UserType.barber;
import static com.example.buzzrfrontend.data.model.UserType.client;


public class LoginActivity extends AppCompatActivity {

    private UserData uD = new UserData();
    private LoginViewModel loginViewModel;
    private RequestQueue requestQueue;

    ApplicationVar appVar;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        appVar = (ApplicationVar) getApplicationContext();
        appVar.getNav().setContext(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        loginViewModel = ViewModelProviders.of(this, new LoginViewModelFactory())
                .get(LoginViewModel.class);

        final Context contxt = this;
        final EditText usernameEditText = findViewById(R.id.username);
        final EditText passwordEditText = findViewById(R.id.password);
        final Button loginButton = findViewById(R.id.login);
        final ProgressBar loadingProgressBar = findViewById(R.id.loading);
        final Button registerButton = findViewById(R.id.register);

        loginViewModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
            @Override
            public void onChanged(@Nullable LoginFormState loginFormState) {
                if (loginFormState == null) {
                    return;
                }
                loginButton.setEnabled(loginFormState.isDataValid());
                if (loginFormState.getUsernameError() != null) {
                    usernameEditText.setError(getString(loginFormState.getUsernameError()));
                }
                if (loginFormState.getPasswordError() != null) {
                    passwordEditText.setError(getString(loginFormState.getPasswordError()));
                }
            }
        });

        loginViewModel.getLoginResult().observe(this, new Observer<LoginResult>() {
            @Override
            public void onChanged(@Nullable LoginResult loginResult) {
                if (loginResult == null) {
                    return;
                }
                loadingProgressBar.setVisibility(View.GONE);
                if (loginResult.getError() != null) {
                    showLoginFailed(loginResult.getError());
                }
                if (loginResult.getSuccess() != null)
                {
                    switch(appVar.getLoggedInUser().getUserType())
                    {
                        case client:
                            appVar.getNav().openToDashboard();
                            break;
                        case barber:
                            appVar.getNav().openToBarberDashboard();
                            break;
                        case admin:
                            appVar.getNav().openToAdminDashboard();
                            break;
                    }
                    setResult(Activity.RESULT_OK);
                    finish();
                }
                else
                {
                    Toast.makeText(LoginActivity.this, "Login Failed!", Toast.LENGTH_SHORT).show();
                }

            }
        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                loginViewModel.loginDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());
            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    loginViewModel.login(usernameEditText.getText().toString(),
                            passwordEditText.getText().toString(), contxt);
                }
                return false;
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboardFrom(LoginActivity.this, findViewById(android.R.id.content));
                if(checkPW(usernameEditText.getText().toString(), passwordEditText.getText().toString())) {
                    loadingProgressBar.setVisibility(View.VISIBLE);
                    loginViewModel.login(usernameEditText.getText().toString(),
                            passwordEditText.getText().toString(), contxt);
                }
                else
                {
                    Toast.makeText(LoginActivity.this, "Incorrect Username or Password!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appVar.getNav().openToRegisterActivity();
            }
        });


        jsonArrGet();
    }
    List<UserData> users = new ArrayList<UserData>();
    public void jsonArrGet() {
        requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest req = new JsonArrayRequest(Const.URL + "/persons",
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i = 0; i < response.length(); i++)
                        {
                            try {
                                JSONObject JsonObj = response.getJSONObject(i);
                                UserData temp = new UserData();
                                temp.setId(JsonObj.getInt("id"));
                                temp.setName(JsonObj.getString("name"));
                                temp.setUserName(JsonObj.getString("username"));
                                temp.setPassword(JsonObj.getString("password"));
                                temp.setEmail(JsonObj.getString("email"));
                                temp.setPhoneNumber(JsonObj.getString("phonenumber"));
                                UserType userType;
                                switch(JsonObj.getString("userType"))
                                {
                                    case "Client":
                                    case "client":
                                        userType = client;
                                        break;
                                    case "Barber:":
                                    case "barber":
                                        userType = barber;
                                        break;
                                    case "admin":
                                    case "Admin":
                                        userType = admin;
                                        break;
                                    default:
                                        userType = null;
                                        break;
                                }
                                temp.setUserType(userType);
                                users.add(temp);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        Toast.makeText(LoginActivity.this, "LOADED", Toast.LENGTH_SHORT).show();
                        Log.d("Volley", response.toString());
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(LoginActivity.this, "Connection to the Server Failed", Toast.LENGTH_SHORT).show();
                VolleyLog.d("Volley", "Error: " + error.getMessage());
            }

        });
        requestQueue.add(req);
    }
    public boolean checkPW(String username, String password) // this should be authenticated on the backend
    {
        for(int u = 0; u < users.size(); u++)
        {
            //Log.d("login", username + ":" + password + " = "+ users.get(u).getUserName() + ":" + users.get(u).getPassword());
            if(username.equals(users.get(u).getUserName()))
            {
                if(password.equals(users.get(u).getPassword()))
                {
                    appVar.setLoggedInUser(new LoggedInUser(users.get(u)));
                    return true;
                }
                return false;
            }
        }
        return false;
    }
    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }
    public static void hideKeyboardFrom(Context context, View view) {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}