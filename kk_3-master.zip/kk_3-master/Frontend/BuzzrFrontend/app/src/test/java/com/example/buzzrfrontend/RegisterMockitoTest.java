package com.example.buzzrfrontend;

import com.example.buzzrfrontend.data.model.UserData;
import com.example.buzzrfrontend.data.model.UserType;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class RegisterMockitoTest {
    @Mock
    UserData uD;

    @Before
    public void setupUserdata()
    {
        uD = new UserData(
                1,
            "New User",
            "NewUsername",
            "newEmail@Email.com",
            "5554245255",
                UserType.client);
    }

    @Test
    public void test()
    {
        //insert test here
    }

}
