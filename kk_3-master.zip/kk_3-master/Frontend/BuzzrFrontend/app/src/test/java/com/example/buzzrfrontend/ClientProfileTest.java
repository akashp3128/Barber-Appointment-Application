package com.example.buzzrfrontend;

import com.example.buzzrfrontend.data.Navigation;
import com.example.buzzrfrontend.data.model.LoggedInUser;
import com.example.buzzrfrontend.data.model.UserData;
import com.example.buzzrfrontend.ui.barberprofile.Booking;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ClientProfileTest {
    @Mock
    Navigation navigation = mock(Navigation.class);

    @Test
    public void testTransition() {
        // doReturn(null).when(navigation).openToBarberProfileActivity(1);
        navigation.openToBarberProfileActivity(1);
        assert(navigation.getProfileId() == 1);
    }

    @Test
    public void testBookingActivity() {
        // doReturn(null).when(navigation).openToBookingActivity("12/12/12");
        navigation.openToBookingActivity("12/12/12");
        // navigation.getContext().getApplicationContext().getAssets()
        assert(true);
    }

}
