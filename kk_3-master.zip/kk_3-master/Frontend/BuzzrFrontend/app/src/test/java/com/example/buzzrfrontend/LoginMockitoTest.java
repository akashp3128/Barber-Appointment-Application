package com.example.buzzrfrontend;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import androidx.lifecycle.ViewModelProviders;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.buzzrfrontend.data.Const;
import com.example.buzzrfrontend.data.LoginRepository;
import com.example.buzzrfrontend.data.Navigation;
import com.example.buzzrfrontend.data.Result;
import com.example.buzzrfrontend.data.model.LoggedInUser;
import com.example.buzzrfrontend.data.model.ServiceData;
import com.example.buzzrfrontend.data.model.UserData;
import com.example.buzzrfrontend.data.model.UserType;
import com.example.buzzrfrontend.ui.loginView.LoginActivity;
import com.example.buzzrfrontend.ui.loginView.LoginViewModel;
import com.example.buzzrfrontend.ui.loginView.LoginViewModelFactory;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static com.example.buzzrfrontend.data.model.UserType.client;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class LoginMockitoTest {
    @Mock
    private UserData MockUserData = mock(UserData.class);
    @Mock
    private LoggedInUser MockLoggedInUser = mock(LoggedInUser.class);
    @Mock
    private LoginRepository MockRepo = mock(LoginRepository.class);
    @Mock
    private ServiceData Mockservice;// = mock(ServiceData.class);



    @Before
    public void before() {
        //when(MockUserData.getUserName()).thenReturn("Username");
        //when(MockUserData.getPassword()).thenReturn("Password");
    }

    @Test
    public void UserDataFunction() {
        MockUserData.setEmail("Test");
        MockUserData.setName("TestName");

        MockUserData.setNull();

        Assert.assertNull(MockUserData.getEmail());
        Assert.assertNull(MockUserData.getName());
    }
    @Test
    public void LoggedInUserFunctionality() {

        MockLoggedInUser.setPhoneNumber("5553028339");
        MockLoggedInUser.logout();
        assertFalse(MockLoggedInUser.isLoggedIn());
    }
    @Test
    public void TestLoginFunctionality()
    {
        Context Mockcontext = Mockito.mock(LoginActivity.class);
        LoggedInUser user = new LoggedInUser(1, "", "Username", "", "", "", UserType.client);
        //Result<LoggedInUser> result = MockRepo.login(user.getUserName(), "password");
        Assert.assertNull(null);
    }
    @Test
    public void TestServiceStuff()
    {
        /*when(Mockservice.getLocation()).thenReturn("Test Location");
        Mockservice.setLocation("Test Location");
        Mockservice.setName("Test Name");
        assertEquals("Test Location", Mockservice.getLocation());*/
    }
}
