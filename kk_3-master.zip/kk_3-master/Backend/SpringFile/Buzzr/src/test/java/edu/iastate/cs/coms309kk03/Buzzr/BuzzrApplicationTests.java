package edu.iastate.cs.coms309kk03.Buzzr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuzzrApplicationTests {

	@Test
	void contextLoads() {
	}

}
