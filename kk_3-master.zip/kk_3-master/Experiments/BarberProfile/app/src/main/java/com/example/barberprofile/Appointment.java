package com.example.barberprofile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Appointment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);
    }
}