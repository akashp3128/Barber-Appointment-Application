package com.example.bullsrent.net_utils;

public class Const
{
    public static final String URL_JSON_OBJECT = "http://coms-309-kk-03.cs.iastate.edu:8080/product";
    public static final String URL_JSON_ARRAY = "http://coms-309-kk-03.cs.iastate.edu:8080/product";
    public static final String URL_STRING_REQ = "https://api.androidhive.info/volley/string_response.html";
    public static final String URL_IMAGE = "https://api.androidhive.info/volley/volley-image.jpg";
}
