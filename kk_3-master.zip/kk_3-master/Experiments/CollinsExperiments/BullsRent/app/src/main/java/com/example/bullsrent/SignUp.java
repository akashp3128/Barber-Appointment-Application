package com.example.bullsrent;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.RetryPolicy;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputLayout;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;



import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
//import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.bullsrent.app.AppController;
import com.example.bullsrent.net_utils.Const;

//import org.json.JSONArray;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;





public class SignUp extends AppCompatActivity {


    TextInputLayout regName, regUsername, regEmail, regPhoneNo, regPassword;
    Button regBtn, regToLoginBtn;

    //FirebaseDatabase rootNode;
    //DatabaseReference reference;

    //ProgressDialog pDialog;

    public static final String TAG = "HELP";
    RequestQueue Queue;
    String URL, username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_sign_up);


        //Instantiate request queue to send request

        //Set base url, makes it easier to change urls later
        //Stored my url in strings.xml(values/strings.xml)
        //URL = getResources().getString(R.string.local);
        //URL = "https://coms-309-kk-03.cs.iastate.edu:8080";

        //HOOKS
        regName = findViewById(R.id.name);
        regUsername = findViewById(R.id.username);
        regEmail = findViewById(R.id.email);
        regPhoneNo = findViewById(R.id.phoneNo);
        regPassword = findViewById(R.id.password);
        regBtn = findViewById(R.id.gobut);
        regToLoginBtn = findViewById(R.id.loginbut);

        regBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //rootNode = FirebaseDatabase.getInstance();
                //reference = rootNode.getReference("users");

                //Get all the values from text fields
                String name = regName.getEditText().getText().toString();
                String username = regUsername.getEditText().getText().toString();
                String email = regEmail.getEditText().getText().toString();
                String phoneNo = regPhoneNo.getEditText().getText().toString();
                String password = regPassword.getEditText().getText().toString();


                UserHelperClass user = new UserHelperClass(name, username, email, phoneNo, password);


                //JsonRequestHelper j = new JsonRequestHelper(pDialog, userHelperClass);

                //j.makeJsonObjReq();

                httpPostTest(user);

            }
        });
    }


    private void httpPostTest(UserHelperClass user) {
        String url = "http://10.24.226.178:8080/product";
        // String url = "http://coms-309-kk-03.cs.iastate.edu:8080/product";
        Queue = Volley.newRequestQueue(this);

        Map<String, String> params = new HashMap<String, String>();
        params.put("name", user.getName());
        params.put("username", user.getUsername());
        params.put("email", user.getEmail());
        params.put("phonenumber", user.getPhoneNo());
        params.put("password", user.getPassword());
        //params.put("phoneNo", user.getPhoneNo());

        JSONObject userInfo = new JSONObject(params);


        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, userInfo,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.i("API account/add", response.toString());
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("API account/add", error.toString());
            }
        }
        );

       // request.setShouldCache(false);
        Queue.add(request);
    }
}








