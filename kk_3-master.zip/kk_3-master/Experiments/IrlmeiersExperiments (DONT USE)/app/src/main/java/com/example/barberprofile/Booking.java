package com.example.barberprofile;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TimePicker;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class Booking extends AppCompatActivity {

    TimePicker picker;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        picker = (TimePicker) findViewById(R.id.timePicker);
        picker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker timePicker, int hour, int minute) {
                button.setText(newTime(hour, minute));
            }
        });

        button = (Button) findViewById(R.id.button_confirm);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity();
            }
        });
    }

    public void openNewActivity(){
        Intent MainActivity = new Intent(this, ProfileActivity.class);
        startActivity(MainActivity);
    }

    public static String newTime(int hour, int minute)
    {
        DecimalFormat formatter = new DecimalFormat("00");
        String minuteFormatted = formatter.format(minute);

        if(hour == 0)
        {
            return("Confirm Time of: " + (hour + 12) + ":" + minuteFormatted + " AM");
        }
        else if(hour < 12)
        {
            return("Confirm Time of: " + hour + ":" + minuteFormatted + " AM");
        }
        else if(hour == 12)
        {
            return("Confirm Time of: " + hour + ":" + minuteFormatted + " PM");
        }
        else
        {
            return("Confirm Time of: " + (hour - 12) + ":" + minuteFormatted + " PM");
        }
    }
}