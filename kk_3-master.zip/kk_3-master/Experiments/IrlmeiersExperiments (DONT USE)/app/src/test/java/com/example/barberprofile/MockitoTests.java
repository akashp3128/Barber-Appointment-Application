package com.example.barberprofile;

import android.content.Context;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static com.example.barberprofile.Appointment.newDate;
import static com.example.barberprofile.Booking.newTime;
import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class MockitoTests {

    @Mock
    private Context context;

    @Mock
    private Appointment appointment;

    @Mock
    private Booking booking;

    @Test
    public void whenDateChanges()
    {
        int day = 30;
        int month = 10;
        int year = 2020;

        month -= 1;
        assertEquals(newDate(day, month, year), "Pick Time For: 10 / 30 / 2020");
    }

    @Test
    public void whenTimeChangesHourEqualsZero()
    {
        int hour = 12;
        int minute = 30;

        assertEquals(newTime(hour, minute),  "Confirm Time of: 12:30 PM");
    }

    @Test
    public void whenTimeChangesHourLessThanTwelve()
    {
        int hour = 6;
        int minute = 30;

        assertEquals(newTime(hour, minute), "Confirm Time of: 6:30 AM");
    }

    @Test
    public void whenTimeChangesHourMoreThanTwelve()
    {
        int hour = 16;
        int minute = 30;

        assertEquals(newTime(hour, minute), "Confirm Time of: 4:30 PM");
    }

    @Test
    public void whenTimeChangesHourEqualsTwelve()
    {
        int hour = 12;
        int minute = 30;

        assertEquals(newTime(hour, minute), "Confirm Time of: 12:30 PM");
    }
}
