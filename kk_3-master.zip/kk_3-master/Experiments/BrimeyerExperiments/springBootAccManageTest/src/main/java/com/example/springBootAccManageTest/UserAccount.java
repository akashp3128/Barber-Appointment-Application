package com.example.springBootAccManageTest;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotBlank;
import java.util.UUID;

public class UserAccount {
    @NotBlank
    private final String userName;
    @NotBlank
    private final String passWord; // Most definitely not secure to store as string, but for testing purposes will do for now.

    private final UUID id;

    public UserAccount(@JsonProperty("username") String userName, @JsonProperty("password") String passWord, @JsonProperty("id") UUID id) {
        this.userName = userName;
        this.passWord = passWord;
        this.id = id;
    }
    public UserAccount(UserAccount user) {
        this.userName = user.getUserName();
        this.passWord = user.getPassWord();
        this.id = user.getID();
    }
    public String getUserName() {
        return userName;
    }

    public String getPassWord() {
        return passWord;
    }

    public UUID getID() {
        return id;
    }
}
