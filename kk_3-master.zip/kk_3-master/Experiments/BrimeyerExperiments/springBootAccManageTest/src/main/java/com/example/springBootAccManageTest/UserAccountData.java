package com.example.springBootAccManageTest;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


@Repository("UserAccTest")
public class UserAccountData {
    private List<UserAccount> MemDB = new ArrayList<>();

    public boolean addNewUser(UserAccount user)
    {
        MemDB.add(new UserAccount(user.getUserName(), user.getPassWord(), UUID.randomUUID()));
        return true;
    }
    public boolean removeUserByName(String userName)
    {
        for(UserAccount user: MemDB)
        {
            UserAccount temp = getUserByName(userName);
            if(temp != null)
            {
                MemDB.remove(temp);
                return true;
            }
            return false;
        }
        return false;
    }
    public boolean changePassword(String userName, String passWord)
    {
        UserAccount temp = new UserAccount(getUserByName(userName));
        removeUserByName(userName);
        MemDB.add(new UserAccount(temp.getUserName(), passWord, temp.getID()));
        return true;
    }
    public List<UserAccount> getAllUsers()
    {
        return MemDB;
    }
    public UserAccount getUserByName(String userName)
    {
        for(UserAccount user: MemDB)
        {
            if(user.getUserName().equals(userName))
            {
                return user;
            }
        }
        return null;
    }
    public UserAccount getUserByID(UUID id)
    {
        for(UserAccount user: MemDB)
        {
            if(user.getID().equals(id))
            {
                return user;
            }
        }
        return null;
    }
}
