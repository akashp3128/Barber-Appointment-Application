package com.example.springBootAccManageTest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.UUID;

@RequestMapping("api/userTest")
@RestController
public class UserAccountManage {

    private final UserAccountData uAD;
    @Autowired
    public UserAccountManage(UserAccountData uAD)
    {
        this.uAD = uAD;
    }
    @PostMapping
    public void addNewUser(@Valid @NonNull @RequestBody UserAccount user)
    {
        uAD.addNewUser(user);
    }
    @PutMapping
    public void changePassword(@PathVariable("userName")String userName,@PathVariable("password") @Valid @NonNull @RequestBody String newPw)
    {
        uAD.changePassword(userName, newPw);
    }
    @GetMapping
    public List<UserAccount> getAllUsers()
    {
        return uAD.getAllUsers();
    }
    @GetMapping(path = "{id}")
    public UserAccount getUserByID(@PathVariable("id") UUID id)
    {
        return uAD.getUserByID(id);
    }
    @GetMapping(path = "find/{userName}")
    public UserAccount getUserByName(@PathVariable("userName") String userName)
    {
        return uAD.getUserByName(userName);
    }
    @DeleteMapping(path = "remove/{userName}")
    public void removeUserByName(@PathVariable("userName") String userName)
    {
        uAD.removeUserByName(userName);
    }

}
