package com.example.springBootAccManageTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAccManageTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
