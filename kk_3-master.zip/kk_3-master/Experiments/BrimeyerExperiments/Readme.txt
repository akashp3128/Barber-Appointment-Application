HelloWorld2 Application - Just a quick test of android studio

CalcDistance Application - just a longer test of android studio,
                           uses distance formula to calculate distance between two points user taps on screen.
                           
SpringbootAccManageTest Application - Personal exploration of how springboot works tested with postman