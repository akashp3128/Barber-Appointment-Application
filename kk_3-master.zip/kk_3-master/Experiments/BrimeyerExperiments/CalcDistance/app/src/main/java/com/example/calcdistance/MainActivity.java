package com.example.calcdistance;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    final int unRchableVal = -1;
    int ptTrack;
    float x1 = unRchableVal, y1 = unRchableVal, x2 = unRchableVal, y2 = unRchableVal;
    boolean b = false;
    TextView outPutNumber;
    View tchGrid;
    Button rstBtn;
    ToggleButton tB1;
    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        outPutNumber = (TextView) findViewById(R.id.numOut);
        tchGrid = (View) findViewById(R.id.grid);

        tB1 = (ToggleButton) findViewById(R.id.choosePt1);

        rstBtn = (Button) findViewById(R.id.resetButton);
        rstBtn.setOnClickListener(new View.OnClickListener(){
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v)
            {
                x1 = unRchableVal;
                y1 = unRchableVal;
                x2 = unRchableVal;
                y2 = unRchableVal;
                ptTrack = 1;
                tB1.setChecked(false);
                outPutNumber.setText("-");
            }
        });

        tchGrid.setOnTouchListener(new View.OnTouchListener(){
            @SuppressLint("SetTextI18n")
            @Override
            public boolean onTouch(View v, MotionEvent event)
            {
                if(tB1.isChecked())
                {
                    ptTrack = 1;
                }
                if(!tB1.isChecked())
                {
                    ptTrack = 2;
                }
                switch (ptTrack) {
                    case 1:
                        x1 = event.getX();
                        y1 = event.getY();
                        break;
                    case 2:
                        x2 = event.getX();
                        y2 = event.getY();
                        break;
                }
                if (x1 != unRchableVal && x2 != unRchableVal) {
                    float out = (float) (Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2)));
                    outPutNumber.setText("" + out);
                    tB1.setChecked(true);
                    return true;
                }
                return false;
            }
        });
    }
}